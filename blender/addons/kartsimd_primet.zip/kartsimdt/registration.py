import bpy

from .preferences import KartSimDTPreferences
from .operators.build_engineering_scene import (
    BuildEngineeringSceneOperator,
)
from .operators.export_calibration import (
    ExportCalibrationOperator,
)
from .panels.panel import (
    KartSimDTPanel,
)

CLASSES = (
    KartSimDTPreferences,
    BuildEngineeringSceneOperator,
    ExportCalibrationOperator,
    KartSimDTPanel,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)