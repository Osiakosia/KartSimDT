from __future__ import annotations

from ..project import setup_project_path

import bpy


class ExportCalibrationOperator(
    bpy.types.Operator,
):
    bl_idname = "kartsimdt.export_calibration"
    bl_label = "Export Calibration"

    def execute(
        self,
        context,
    ):
        setup_project_path()

        from blender.exporters.export_calibration import (
            export_calibration,
        )

        export_calibration()

        return {"FINISHED"}